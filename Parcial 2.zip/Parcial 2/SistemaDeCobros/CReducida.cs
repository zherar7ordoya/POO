﻿namespace SistemaDeCobros
{
    public class CReducida
    {
        public string Nombre { get; set; }
        public decimal Total { get; set; }
    }
}
