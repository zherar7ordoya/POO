﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13_De_todo_03.Vistas
{
    public class Class1
    {
        public int Nada { get; set; }
    }
}
